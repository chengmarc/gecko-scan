# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 10:34:43 2023

@author: uzcheng
"""
from setuptools import setup, find_packages

setup(
    name='dependencies',
    version='1.0',
    packages=find_packages(),
    install_requires=['requests', 'pandas', 'bs4', 'colorama']
)